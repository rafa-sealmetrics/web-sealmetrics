"use client";

import { useMemo, useState } from "react";

export function DataLossCalculator() {
  const [sessions, setSessions] = useState(250000);
  const [revenue, setRevenue] = useState(500000);
  const [consent, setConsent] = useState(42);
  const result = useMemo(() => {
    const visible = Math.max(1, Math.min(100, consent));
    return {
      sessions: Math.round(sessions * (1 - visible / 100)),
      revenue: Math.round(revenue * (1 - visible / 100)),
      totalRevenue: Math.round(revenue / (visible / 100)),
    };
  }, [sessions, revenue, consent]);

  const euros = new Intl.NumberFormat("en-IE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 });
  const number = new Intl.NumberFormat("en-IE");

  return (
    <div className="calculator-module">
      <div className="calculator-inputs">
        <label>Monthly measured sessions<input type="number" min="0" value={sessions} onChange={e => setSessions(Number(e.target.value))} /></label>
        <label>Monthly measured revenue<input type="number" min="0" value={revenue} onChange={e => setRevenue(Number(e.target.value))} /></label>
        <label>Consent / visible rate<input type="range" min="10" max="100" value={consent} onChange={e => setConsent(Number(e.target.value))} /><b>{consent}% visible</b></label>
      </div>
      <div className="calculator-result">
        <span>ESTIMATED BLIND SPOT</span>
        <strong>{euros.format(result.revenue)}</strong>
        <p>revenue likely absent from the measured view</p>
        <div><b>{number.format(result.sessions)}</b><span>sessions missing</span></div>
        <div><b>{euros.format(result.totalRevenue)}</b><span>estimated total reality</span></div>
        <small>Illustrative estimate. Measure side by side to quantify your real gap.</small>
      </div>
    </div>
  );
}
