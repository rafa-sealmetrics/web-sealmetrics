export function BrandLockup({ large = false }: { large?: boolean }) {
  return (
    <span className={`brand-lockup${large ? " brand-lockup-large" : ""}`} aria-label="SealMetrics">
      <span className="brand-seal" aria-hidden="true">Seal</span><span className="brand-metrics" aria-hidden="true">Metrics</span>
    </span>
  );
}

const productLinks = [
  ["Platform overview", "/product/"],
  ["How it works", "/how-it-works/"],
  ["Consentless analytics", "/consentless-analytics/"],
  ["LENS AI", "/ai-analytics/"],
  ["Integrations", "/integrations/"],
  ["Platforms", "/platforms/"],
  ["Security", "/security/"],
];

const solutionLinks = [
  ["For CMOs", "/for/cmo/"],
  ["For CTOs", "/for/cto/"],
  ["eCommerce", "/for/ecommerce/"],
  ["Hotels & Travel", "/for/hotels/"],
  ["SaaS", "/for/saas/"],
  ["Agencies", "/for/agencies/"],
  ["Media & Publishers", "/for/media/"],
  ["Finance", "/for/finance/"],
  ["Healthcare", "/for/healthcare/"],
  ["Education", "/for/education/"],
];

const resourceLinks = [
  ["Blog", "/blog/"],
  ["Case studies", "/case-studies/"],
  ["Videos", "/videos/"],
  ["Glossary", "/glossary/"],
  ["Changelog", "/changelog/"],
  ["Data loss calculator", "/data-loss-calculator/"],
];

function NavMenu({ label, links }: { label: string; links: string[][] }) {
  return (
    <details className="nav-menu">
      <summary>{label}<span aria-hidden="true">＋</span></summary>
      <div className="nav-panel">
        {links.map(([name, href]) => <a href={href} key={href}>{name}<span aria-hidden="true">↗</span></a>)}
      </div>
    </details>
  );
}

export function SiteHeader() {
  return (
    <header className="global-header">
      <a className="global-wordmark" href="/" aria-label="SealMetrics home"><BrandLockup /></a>
      <nav className="global-nav" aria-label="Main navigation">
        <NavMenu label="Product" links={productLinks} />
        <a href="/why-sealmetrics/">Why SealMetrics</a>
        <NavMenu label="Solutions" links={solutionLinks} />
        <a href="/pricing/">Pricing</a>
        <NavMenu label="Resources" links={resourceLinks} />
      </nav>
      <div className="global-actions">
        <a className="nav-language" href="https://sealmetrics.com/es/" lang="es">ES</a>
        <a className="nav-demo" href="/demo/">Book a demo</a>
        <a className="nav-trial" href="https://my.sealmetrics.com/register">Start free trial <span aria-hidden="true">↗</span></a>
      </div>
    </header>
  );
}

const footerGroups = [
  ["Product", productLinks.slice(0, 7)],
  ["Solutions", solutionLinks],
  ["Compare", [
    ["vs Google Analytics 4", "/vs-ga4/"],
    ["vs GA360", "/vs/ga360/"],
    ["vs Adobe Analytics", "/vs/adobe-analytics/"],
    ["vs Piwik PRO", "/vs/piwik-pro/"],
    ["Your real ROAS", "/real-roas/"],
  ]],
  ["Resources", resourceLinks],
  ["Company", [
    ["About", "/about/"],
    ["Work with us", "/careers/"],
    ["Trust Center", "/trust/"],
    ["Privacy Policy", "/privacy/"],
    ["Terms of Service", "/terms/"],
    ["DPA", "/dpa/"],
  ]],
];

export function SiteFooter() {
  return (
    <footer className="global-footer">
      <div className="footer-lead">
        <BrandLockup large />
        <h2>Complete data.<br /><em>Fewer expensive opinions.</em></h2>
        <div><a className="footer-demo" href="https://my.sealmetrics.com/register">Start 14-day free trial ↗</a><a href="/demo/">Book a demo</a><a href="/demo-access/">Explore the demo account</a></div>
      </div>
      <div className="footer-map">
        {footerGroups.map(([group, links]) => (
          <div key={group as string}>
            <b>{group as string}</b>
            {(links as string[][]).map(([name, href]) => <a href={href} key={href}>{name}</a>)}
          </div>
        ))}
      </div>
      <div className="footer-bottom"><span>© 2026 SealMetrics · Built and hosted in Europe</span><span>The analytics of reality.</span></div>
    </footer>
  );
}
