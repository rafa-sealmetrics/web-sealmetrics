import type { Metadata } from "next";
import type { CSSProperties } from "react";
import { DataLossCalculator } from "../components/data-loss-calculator";
import { SiteFooter, SiteHeader } from "../components/site-shell";
import { pages, type PageData } from "../page-data";

function pathFrom(slug: string[]) { return slug.join("/"); }

export function generateStaticParams() {
  return Object.keys(pages).map(path => ({ slug: path.split("/") }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string[] }> }): Promise<Metadata> {
  const { slug } = await params;
  const page = pages[pathFrom(slug)];
  return page ? { title: page.title, description: page.description } : { title: "SealMetrics" };
}

function Emphasis({ children }: { children: string }) {
  const bits = children.split("*");
  return <>{bits.map((bit, index) => index % 2 ? <em key={index}>{bit}</em> : bit)}</>;
}

function Stats({ page }: { page: PageData }) {
  if (!page.stats?.length) return null;
  return <div className="inner-stats">{page.stats.map(stat => <div key={stat.label}><strong>{stat.value}</strong><span>{stat.label}</span></div>)}</div>;
}

function SalesProof({ page }: { page: PageData }) {
  const pain = page.problems?.[0]?.body ?? page.intro;
  const outcome = page.solutions?.[0]?.body ?? "SealMetrics restores the missing traffic and revenue evidence, so the number on screen can be checked against the system that recorded the sale.";

  return (
    <section className="sales-proof" aria-label="Why try SealMetrics">
      <div className="sales-proof-heading">
        <span>THE FAIR TEST</span>
        <h2>Don&apos;t believe the pitch.<br /><em>Compare the numbers.</em></h2>
      </div>
      <div className="sales-proof-grid">
        <article><b>01 · YOUR PROBLEM</b><p>{pain}</p></article>
        <article><b>02 · WHAT WE FIX</b><p>{outcome}</p></article>
        <article><b>03 · FAST TO PROVE</b><p>Install one lightweight first-party signal. See the first data in minutes and run it beside your current analytics—no migration project.</p></article>
        <article className="sales-proof-trial"><b>04 · ZERO-RISK TEST</b><p>Use the full product free for 14 days, with no commitment. Keep it only if your backend confirms the gap.</p><a href="https://my.sealmetrics.com/register">Start free trial ↗</a></article>
      </div>
    </section>
  );
}

function CardGrid({ title, cards, tone = "paper" }: { title?: string; cards?: PageData["problems"]; tone?: "paper" | "dark" }) {
  if (!cards?.length) return null;
  return (
    <section className={`inner-card-section inner-card-${tone}`}>
      {title && <h2><Emphasis>{title}</Emphasis></h2>}
      <div className="inner-card-grid">
        {cards.map((card, index) => <article key={card.title}><span>{card.label ?? String(index + 1).padStart(2, "0")}</span><h3>{card.title}</h3><p>{card.body}</p></article>)}
      </div>
    </section>
  );
}

function PricingContent() {
  const plans = [
    { label: "NEW · FREE", name: "Agentic Package", price: "Free", desc: "Let your AI assistant create a complete analytics setup.", features: ["Up to 1M human events / month", "Full dashboard, pixels & MCP", "Unlimited sites, users & accounts", "Self-serve · docs only"] },
    { label: "MOST POPULAR · 14 DAYS FREE", name: "Growth", price: "€499/mo", desc: "Prove the missing-data gap before you commit.", features: ["5M human events / month", "3 domains", "MCP + BigQuery + API", "GA4 side-by-side comparison"] },
    { label: "SCALE", name: "Scale", price: "€899/mo", desc: "For serious eCommerce that needs the data to decide.", features: ["15M human events / month", "10 domains", "Everything in Growth", "Founder-led onboarding"] },
    { label: "ENTERPRISE", name: "Enterprise", price: "Custom", desc: "For portfolios and custom integration needs.", features: ["Unlimited events", "Private AI", "BI & warehouse integration", "Dedicated account manager"] },
  ];
  return (
    <section className="plans-grid">
      {plans.map((plan, index) => <article className={index === 1 ? "plan-featured" : ""} key={plan.name}><span>{plan.label}</span><h2>{plan.name}</h2><p>{plan.desc}</p><strong>{plan.price}</strong><ul>{plan.features.map(f => <li key={f}>{f}</li>)}</ul><a href={index === 3 ? "/demo/" : "https://my.sealmetrics.com/register"}>{index === 3 ? "Talk to us" : index === 0 ? "Create free account" : "Start free trial"} ↗</a></article>)}
    </section>
  );
}

function ListingContent({ page }: { page: PageData }) {
  return <section className="resource-list">{page.items?.map((item, index) => <article key={item.title}><span>{item.label ?? String(index + 1).padStart(2, "0")}</span><h2>{item.title}</h2><p>{item.body}</p><a href="#final-action">Read / explore ↗</a></article>)}</section>;
}

function LegalContent({ page }: { page: PageData }) {
  return (
    <section className="legal-layout">
      <aside><b>ON THIS PAGE</b>{page.items?.map(item => <a href={`#${item.title.split(".")[0]}`} key={item.title}>{item.title}</a>)}</aside>
      <div>{page.items?.map(item => <article id={item.title.split(".")[0]} key={item.title}><h2>{item.title}</h2><p>{item.body}</p></article>)}{page.note && <div className="legal-note">{page.note}</div>}</div>
    </section>
  );
}

function IntegrationContent({ page }: { page: PageData }) {
  return <section className="platform-list">{page.items?.map(item => <article key={item.title}><span>{item.label}</span><h2>{item.title}</h2><p>{item.body}</p></article>)}</section>;
}

function DemoContent({ page, path }: { page: PageData; path: string }) {
  return (
    <section className="demo-layout">
      <div><span>WHAT YOU WILL LEAVE WITH</span><h2>One answer worth acting on.</h2><p>We will not walk through every tab. We will focus on the gap between your analytics and the revenue system you already trust.</p><ul><li>Your likely data-loss range</li><li>The channels most exposed to consent loss</li><li>A side-by-side rollout plan</li></ul></div>
      <div className="demo-card"><span>{path === "demo-access" ? "SELF-GUIDED" : "30-MINUTE WALKTHROUGH"}</span><h2>{path === "demo-access" ? "Explore without a sales call." : "Bring your hardest analytics question."}</h2><p>{path === "demo-access" ? "Open the live demo data and inspect the product at your own pace." : "Choose a time on the current booking page. We will prepare before the call."}</p><a href={path === "demo-access" ? "https://lens-lite.sealmetrics.com" : "https://sealmetrics.com/demo/"}>{path === "demo-access" ? "Open demo data" : "Choose a time"} ↗</a></div>
    </section>
  );
}

function WhySealMetricsPage({ page }: { page: PageData }) {
  const shifts = [
    ["01", "Measure the whole market", "No consent gate means the audience does not shrink before the report begins.", "100% observed"],
    ["02", "Put every sale back", "Complete last-click attribution stops ‘Direct’ becoming a landfill for missing evidence.", "0% invented"],
    ["03", "See what actually sells", "Channels, campaigns, products and funnel steps stay connected to backend revenue.", "SKU-level truth"],
    ["04", "Ask better questions", "LENS answers from complete, private, EU-hosted data—not a consent-shaped sample.", "Private AI"],
    ["05", "Prove it before buying", "Run beside GA4 for 14 days. Keep it only when your store confirms the difference.", "No commitment"],
  ];

  return (
    <>
      <div className="signal-bar inner-signal" aria-hidden="true"><span /> LIVE SIGNAL <b>100%</b> TRAFFIC OBSERVED</div>
      <SiteHeader />
      <main className="why-page">
        <section className="why-hero">
          <div className="why-hero-copy">
            <p className="inner-kicker">WHY SEALMETRICS</p>
            <h1>You&apos;re not missing data.<br /><em>You&apos;re funding the wrong winner.</em></h1>
            <p>Consent banners and tracking prevention do more than hide visits. They distort which channels appear to work—then you move real budget using a fictional ranking.</p>
            <div className="inner-actions"><a className="inner-primary" href="https://my.sealmetrics.com/register">Start 14-day free trial <span>↗</span></a><a href="/demo/">Show me the gap →</a></div>
            <p className="inner-micro-proof">One first-party signal · first data in minutes · keep GA4 while you compare</p>
          </div>
          <div className="why-funnel" aria-label="How conventional analytics loses measurement evidence">
            <div className="why-funnel-top"><span>THE MONDAY NUMBER</span><b>REALITY CHECK</b></div>
            <article style={{ "--bar": "100%" } as CSSProperties}><span>Every visit that happened</span><strong>100%</strong><i /></article>
            <article style={{ "--bar": "55%" } as CSSProperties}><span>After the consent wall</span><strong>≈55%</strong><i /></article>
            <article style={{ "--bar": "42%" } as CSSProperties}><span>After blockers & prevention</span><strong>≈42%</strong><i /></article>
            <article className="why-funnel-unknown" style={{ "--bar": "22%" } as CSSProperties}><span>Still in the right channel</span><strong>?</strong><i /></article>
            <p>Your ROAS is calculated on the last bar. Then presented as reality.</p>
          </div>
        </section>

        <section className="why-distortion">
          <div className="why-section-head"><span>THE REAL PROBLEM</span><h2>The missing half <em>doesn&apos;t disappear evenly.</em></h2><p>A smaller but proportional picture would be inconvenient. This is worse: mobile social, paid search and privacy-conscious audiences vanish at different rates. The ranking changes.</p></div>
          <div className="why-channel-compare">
            <article className="channel-wrong">
              <div><span>HOW CONSENT-GATED ANALYTICS SEES IT</span><b>SKEWED</b></div>
              {[['Paid social','14%'],['Paid search','22%'],['Brand search','34%'],['Email / Direct','30%']].map(([name,value]) => <p key={name}><span>{name}</span><strong>{value}</strong></p>)}
              <footer>Logical decision: <b>cut social.</b></footer>
            </article>
            <article className="channel-real">
              <div><span>WHAT ACTUALLY HAPPENED</span><b>COMPLETE</b></div>
              {[['Paid social','35%'],['Paid search','25%'],['Brand search','20%'],['Email / Direct','20%']].map(([name,value]) => <p key={name}><span>{name}</span><strong>{value}</strong></p>)}
              <footer>Actual decision: <b>protect acquisition.</b></footer>
            </article>
          </div>
          <p className="why-caption">Illustrative channel mix. The point is not these percentages; it is that only your own complete traffic can reveal your skew.</p>
        </section>

        <section className="why-cost">
          <div className="why-section-head why-section-light"><span>THE EXPENSIVE CASCADE</span><h2>Same budget. Fewer sales.<br /><em>No idea why.</em></h2></div>
          <div className="why-cost-grid">
            <article><span>01 · YOU SPEND</span><strong>€50K</strong><p>and 1,000 real sales close.</p></article>
            <b aria-hidden="true">→</b>
            <article><span>02 · GA4 SEES</span><strong>≈420</strong><p>skewed by consent and channel.</p></article>
            <b aria-hidden="true">→</b>
            <article><span>03 · YOU CUT</span><strong>−40%</strong><p>from the channel that merely looks weak.</p></article>
            <b aria-hidden="true">→</b>
            <article className="why-cost-result"><span>04 · THE RESULT</span><strong>↓ SALES</strong><p>You optimized the distortion.</p></article>
          </div>
          <p className="why-cost-line">You did not lose money by spending more. <em>You lost it by believing less data was the truth.</em></p>
        </section>

        <section className="why-objection">
          <div className="why-objection-quote"><span>THE LEGITIMATE OBJECTION</span><blockquote>“That revenue already happened. Seeing it doesn&apos;t create more sales.”</blockquote><small>WHAT YOUR CFO IS RIGHT TO SAY</small></div>
          <div className="why-objection-answer"><b>Correct. SealMetrics does not manufacture revenue.</b><p>It restores your ability to repeat the revenue that worked—and stop paying for what did not. The value is not a prettier historical total. It is the next budget decision.</p><div><strong>Same budget.<br /><em>More sales.</em></strong><strong>Same sales.<br /><em>Less budget.</em></strong></div></div>
        </section>

        <section className="why-shifts">
          <div className="why-section-head"><span>WHAT CHANGES</span><h2>Five things become true <em>on day one.</em></h2></div>
          <div className="why-shift-grid">{shifts.map(([number,title,body,proof]) => <article key={number}><span>{number}</span><h3>{title}</h3><p>{body}</p><b>{proof} ↗</b></article>)}</div>
        </section>

        <section className="why-proof">
          <div className="why-proof-copy"><span>AUDITED, NOT CLAIMED</span><h2>Palladium ran the comparison.<br /><em>The gap was 40%.</em></h2><blockquote>“The data SealMetrics delivers is agnostic, unbiased and neutral. There&apos;s no black box.”</blockquote><p>Toni Andújar · Digital & Direct Sales Director</p><a href="/case-studies/">Read the case studies ↗</a></div>
          <div className="why-proof-numbers"><article><strong>40%</strong><span>unattributed traffic recovered</span></article><article><strong>35%</strong><span>bookings recovered from unknown</span></article><article><strong>+165%</strong><span>Display cost efficiency</span></article><div><img src="/logos/clients/palladium-dark.svg" alt="Palladium Hotel Group" /><img src="/logos/clients/dreamplace.svg" alt="Dreamplace Hotels" /></div></div>
        </section>

        <section className="why-test">
          <div className="why-test-script"><span>LIVE IN MINUTES</span><code>&lt;script src=&quot;//app.sealmetrics.com/…&quot;&gt;</code><p>One first-party signal. No tag-manager maze. No migration. No need to remove GA4.</p></div>
          <div className="why-test-copy"><span>THE FAIR TEST</span><h2>The obvious choice is the one <em>you can verify.</em></h2><ol><li><b>01</b> Install in minutes</li><li><b>02</b> Run side by side for 14 days</li><li><b>03</b> Compare both with backend sales</li></ol><p>If the gap is not worth acting on, keep what you have.</p><a href="https://my.sealmetrics.com/register">Start 14-day free trial ↗</a><small>No commitment · no forced migration · no card required</small></div>
        </section>

        <section className="inner-final"><span>MONDAY IS COMING</span><h2>Walk in with a number<br /><em>no one argues with.</em></h2><p>Complete traffic. Verified revenue. One view for marketing, finance and the agency.</p><div><a href="https://my.sealmetrics.com/register">Start free trial ↗</a><a href="/demo/">Book a demo →</a></div><small>First data in minutes. Free for 14 days. Decide with your own evidence.</small></section>
      </main>
      <SiteFooter />
    </>
  );
}

export default async function ContentPage({ params }: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await params;
  const path = pathFrom(slug);
  const page = pages[path];

  if (!page) return <><SiteHeader /><main className="inner-page"><section className="inner-hero"><p className="inner-kicker">404 · REALITY CHECK</p><h1>This page is <em>actually missing.</em></h1><p>Unlike modeled analytics, we will not invent it.</p><a className="inner-primary" href="/">Back home ↗</a></section></main><SiteFooter /></>;

  if (path === "why-sealmetrics") return <WhySealMetricsPage page={page} />;

  return (
    <>
      <div className="signal-bar inner-signal" aria-hidden="true"><span /> LIVE SIGNAL <b>100%</b> TRAFFIC OBSERVED</div>
      <SiteHeader />
      <main className={`inner-page inner-kind-${page.kind ?? "landing"}`}>
        <section className="inner-hero">
          <p className="inner-kicker">{page.eyebrow}</p>
          <h1><Emphasis>{page.hero}</Emphasis></h1>
          <p className="inner-intro">{page.intro}</p>
          <p className="inner-decision">{page.cta ?? "See the full picture on your own data."}</p>
          <div className="inner-actions"><a className="inner-primary" href="https://my.sealmetrics.com/register">Start 14-day free trial <span>↗</span></a><a href={path === "demo" ? "https://sealmetrics.com/demo/" : "/demo/"}>See it on my data →</a></div>
          <p className="inner-micro-proof">First data in minutes · runs beside your current analytics · no commitment</p>
        </section>

        <SalesProof page={page} />
        <Stats page={page} />

        {page.kind === "pricing" && <PricingContent />}
        {page.kind === "listing" && <ListingContent page={page} />}
        {page.kind === "legal" && <LegalContent page={page} />}
        {page.kind === "calculator" && <section className="calculator-wrap"><DataLossCalculator /></section>}
        {page.kind === "integrations" && <IntegrationContent page={page} />}
        {page.kind === "demo" && <DemoContent page={page} path={path} />}

        {!page.kind || page.kind === "landing" ? <><CardGrid title={page.problemTitle} cards={page.problems} /><CardGrid title={page.solutionTitle} cards={page.solutions} tone="dark" /></> : null}
        {page.kind === "demo" && page.problems?.length ? <CardGrid cards={page.problems} /> : null}

        <section className="inner-final" id="final-action"><span>THE LOW-RISK DECISION</span><h2><Emphasis>{page.cta ?? "See the full picture on your own data."}</Emphasis></h2><p>Install it in minutes. Run it beside the analytics you already have for 14 days. Let your backend decide which version is reality.</p><div><a href="https://my.sealmetrics.com/register">Start free trial ↗</a><a href="/demo/">Book a demo →</a></div><small>No commitment. No forced migration. Keep your current stack while you compare.</small></section>
      </main>
      <SiteFooter />
    </>
  );
}
