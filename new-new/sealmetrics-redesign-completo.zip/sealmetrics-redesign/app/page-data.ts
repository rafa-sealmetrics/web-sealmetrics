export type ContentCard = { title: string; body: string; label?: string };
export type Stat = { value: string; label: string };
export type PageData = {
  title: string;
  description: string;
  eyebrow: string;
  hero: string;
  intro: string;
  stats?: Stat[];
  problemTitle?: string;
  problems?: ContentCard[];
  solutionTitle?: string;
  solutions?: ContentCard[];
  note?: string;
  cta?: string;
  kind?: "landing" | "pricing" | "listing" | "legal" | "calculator" | "integrations" | "demo";
  items?: ContentCard[];
};

const defaultCta = "See the full picture on your own data.";

function rolePage(input: {
  title: string; description: string; eyebrow: string; hero: string; intro: string;
  pains: [string, string][]; changes: [string, string][]; stats?: Stat[]; cta: string;
}): PageData {
  return {
    ...input,
    problems: input.pains.map(([title, body]) => ({ title, body })),
    solutions: input.changes.map(([title, body]) => ({ title, body })),
    problemTitle: "What keeps you up at night.",
    solutionTitle: "What changes when the missing data returns.",
    cta: input.cta,
  };
}

function comparisonPage(input: {
  title: string; description: string; hero: string; intro: string; opponent: string;
  problems: [string, string][]; stats: Stat[]; cta: string;
}): PageData {
  return {
    ...input,
    eyebrow: `SEALMETRICS VS ${input.opponent.toUpperCase()}`,
    problemTitle: `Where ${input.opponent} stops short.`,
    problems: input.problems.map(([title, body]) => ({ title, body })),
    solutionTitle: "Feature by feature. No spin.",
    solutions: [
      { title: "Data capture", body: "SealMetrics observes 100% of aggregate events without consent loss. No sampling and no modeled recovery." },
      { title: "Revenue attribution", body: "Every conversion returns to the channel that earned it, on complete first-party data." },
      { title: "Privacy architecture", body: "No cookies, identifiers or personal profiles. EU-hosted in Dublin." },
      { title: "Time to value", body: "One first-party pixel, side by side with your current stack, without a migration project." },
    ],
    cta: input.cta,
  };
}

export const pages: Record<string, PageData> = {
  "product": {
    title: "Product — SealMetrics · Complete analytics, no compromises",
    description: "Consentless tracking, revenue attribution, LENS AI, API and MCP on 100% observed data.",
    eyebrow: "PLATFORM OVERVIEW",
    hero: "Complete analytics, *without the compromises.*",
    intro: "Four tools. Four numbers. One meeting. SealMetrics replaces consent-shaped reporting with a complete record of what happened—and gives every team the same answer.",
    stats: [{ value: "100%", label: "traffic observed" }, { value: "846 B", label: "first-party pixel" }, { value: "0", label: "personal profiles" }, { value: "LIVE", label: "decision-ready data" }],
    problemTitle: "Four familiar meetings. None of them useful.",
    problems: [
      { title: "The Meta paradox", body: "Meta says a campaign sold. GA4 says it didn't. Finance sees a third number." },
      { title: "The direct / none bucket", body: "The best-converting traffic disappears into the least actionable row." },
      { title: "The reconciliation ritual", body: "Brand, agency and finance spend Monday deciding which dashboard to distrust." },
    ],
    solutionTitle: "Four pillars. One picture.",
    solutions: [
      { title: "Consentless tracking", body: "Observe aggregate hits without cookies, identifiers, fingerprints or a consent wall." },
      { title: "Revenue attribution", body: "Connect every sale to the channel and campaign that actually earned it." },
      { title: "LENS AI", body: "Ask complete data a plain-language question and get an answer you can trace." },
      { title: "API · MCP · BigQuery", body: "Move verified data into the tools and agents your team already uses." },
    ],
    cta: defaultCta,
  },
  "why-sealmetrics": {
    title: "Why SealMetrics — measure 100% of traffic and sales",
    description: "Consent banners hide 40–60% of EU visits. SealMetrics measures reality without cookies.",
    eyebrow: "WHY SEALMETRICS",
    hero: "You're steering the business on *a fraction of the data.*",
    intro: "The missing 40–60% isn't lost evenly. It contains real customers, real sales and the channel evidence behind your next budget decision.",
    stats: [{ value: "40–60%", label: "typical consent blind spot" }, { value: "+30%", label: "traffic recovered at Dreamplace" }, { value: "35%", label: "bookings recovered at Palladium" }],
    problemTitle: "Your ROAS isn't slightly wrong. It's wrong by design.",
    problems: [
      { title: "Uneven loss", body: "Privacy-conscious buyers do not disappear proportionally across every channel." },
      { title: "False efficiency", body: "The channels that retain consent look efficient. The channels that generate revenue may look weak." },
      { title: "The wrong cut", body: "You remove budget from a winner because the sale closed outside your measurement field." },
    ],
    solutionTitle: "Five things become true on day one.",
    solutions: [
      { title: "Measure every visit", body: "Aggregate measurement no longer depends on accepting a banner." },
      { title: "Attribute every sale", body: "Last-click revenue uses complete observed traffic, not a consent subset." },
      { title: "See the SKU", body: "Product-level performance stays visible through the full purchase path." },
      { title: "Trust the AI", body: "LENS answers from private, EU-hosted, complete data." },
    ],
    cta: "Walk into Monday with a number no one argues with.",
  },
  "how-it-works": {
    title: "How SealMetrics Works — First-party, Cookieless, EU-hosted",
    description: "An 846-byte first-party pixel, anonymous event counting and EU-hosted analytics.",
    eyebrow: "HOW IT WORKS",
    hero: "A different approach to *measurement.*",
    intro: "No identity graph. No consent-mode maze. Just a small first-party signal, anonymous server-side counting and decision-ready reporting in Dublin.",
    stats: [{ value: "846 B", label: "pixel weight" }, { value: "1st", label: "first-party signal" }, { value: "EU", label: "Dublin hosting" }, { value: "5 min", label: "first data" }],
    problemTitle: "Three layers. One pipeline.",
    problems: [
      { title: "Observe", body: "The first-party pixel records anonymous aggregate events from your domain." },
      { title: "Count", body: "Server-side processing filters bots and groups events without creating a personal profile." },
      { title: "Decide", body: "Traffic, microconversions, sales and revenue appear in live channel reports." },
    ],
    solutionTitle: "From install to decision-ready in one week.",
    solutions: [
      { title: "Install the pixel", body: "Add one script directly or through your platform's native module." },
      { title: "Run side by side", body: "Keep GA4. Compare both streams against backend revenue." },
      { title: "Track the real funnel", body: "Add cart, checkout, lead and purchase events without identifying people." },
      { title: "Align the team", body: "Make SealMetrics the neutral layer across brand, agency and finance." },
    ],
    cta: "See the pipeline on your own site.",
  },
  "consentless-analytics": {
    title: "Consentless analytics — lawful measurement without banners",
    description: "The architectural route to analytics without consent banners, cookies or personal profiles.",
    eyebrow: "CONSENTLESS ANALYTICS",
    hero: "Lawful by architecture, *not by paperwork.*",
    intro: "Consentless analytics is not a clever banner configuration. It is measurement designed so there is nothing personal to consent to in the first place.",
    stats: [{ value: "0", label: "cookies" }, { value: "0", label: "identifiers" }, { value: "0", label: "fingerprints" }, { value: "100%", label: "aggregate capture" }],
    problemTitle: "Why cookie banners stopped working.",
    problems: [
      { title: "Rejection became material", body: "When large parts of the audience decline, a consent subset stops representing the business." },
      { title: "Dark patterns are enforcement risk", body: "Manipulating acceptance is neither a durable legal strategy nor a decent customer experience." },
      { title: "Banner fatigue costs attention", body: "The first interaction with your brand should not be a legal obstacle." },
    ],
    solutionTitle: "Three architectural anchors.",
    solutions: [
      { title: "No identifiers", body: "No cookies, device IDs, fingerprinting or persistent visitor keys." },
      { title: "No personal data", body: "Events are processed as aggregate measurement, not behavioral profiles." },
      { title: "Strict purpose", body: "Measurement exists to understand audience and performance—not to follow people." },
      { title: "EU-only infrastructure", body: "Processing and storage remain in Dublin under European jurisdiction." },
    ],
    cta: "Measure 100%, legally.",
  },
  "ai-analytics": {
    title: "AI Analytics — Private AI on Complete, EU-Hosted Data",
    description: "Ask Claude or ChatGPT revenue questions against complete, private, EU-hosted analytics.",
    eyebrow: "LENS AI",
    hero: "Ask your analytics anything. *Trust the answer.*",
    intro: "An LLM is the easy part. Trustworthy answers are the hard part. LENS combines complete data, a semantic MCP and private EU-hosted intelligence.",
    stats: [{ value: "100%", label: "observed data" }, { value: "EU", label: "private AI" }, { value: "MCP", label: "semantic access" }, { value: "0 PII", label: "in the model" }],
    problemTitle: "Generic AI inherits every weakness underneath it.",
    problems: [
      { title: "Incomplete warehouse", body: "A clever model cannot recover visitors your measurement never observed." },
      { title: "Schema without meaning", body: "Raw tables make the model guess what revenue, sessions and channels mean." },
      { title: "Untraceable answers", body: "A confident sentence is not evidence unless the team can inspect the source." },
    ],
    solutionTitle: "One AI layer. Every role.",
    solutions: [
      { title: "Growth", body: "Find products and funnel steps leaking revenue before the week is over." },
      { title: "Risk", body: "Surface anomalies, stock-outs and overnight drops before they become a monthly surprise." },
      { title: "Cost", body: "Identify spend that generates attention but not verified sales." },
      { title: "Private by default", body: "Your data remains EU-hosted and trains no shared model." },
    ],
    cta: "Ask LENS on complete data.",
  },
  "integrations": {
    title: "Integrations — SealMetrics",
    description: "Native modules for eCommerce, CMS, frameworks, tag managers, data and AI.",
    eyebrow: "DIRECT CONNECTORS",
    hero: "Plug into *the stack you already run.*",
    intro: "No middleware. No custom engineering. Native modules, a full API, BigQuery and an MCP server for the tools and agents already inside your workflow.",
    kind: "integrations",
    items: [
      { label: "eCommerce", title: "Shopify · Magento · PrestaShop · WooCommerce · OpenCart", body: "Native commerce modules with purchase and product context." },
      { label: "CMS", title: "WordPress · Drupal · Joomla", body: "First-party analytics without a consent-mode dependency." },
      { label: "Website builders", title: "Webflow · Wix · Squarespace", body: "Fast installation without rebuilding the site." },
      { label: "Frameworks", title: "React · Next.js · Vue · Nuxt", body: "SPA-aware tracking and virtual pageview control." },
      { label: "Tag management", title: "Google Tag Manager", body: "Deploy alongside your current stack without surrendering first-party capture." },
      { label: "Data & AI", title: "BigQuery · REST API · MCP · Webhooks", body: "Move complete data wherever decisions happen." },
    ],
    cta: "Install in 15 minutes.",
  },
  "platforms": {
    title: "Platforms — SealMetrics",
    description: "Native installation across commerce platforms, CMS, builders and headless sites.",
    eyebrow: "PLATFORMS",
    hero: "Native on *every eCommerce platform.*",
    intro: "Your platform should determine the install method—not the quality of your analytics. Every route reaches the same complete, consentless data architecture.",
    kind: "integrations",
    items: [
      { label: "Commerce", title: "Shopify", body: "Native storefront and purchase measurement." },
      { label: "Commerce", title: "Magento", body: "Module-based install for serious catalogs and multi-store setups." },
      { label: "Commerce", title: "PrestaShop", body: "Product, cart and order measurement without custom middleware." },
      { label: "Commerce", title: "WooCommerce", body: "WordPress-native analytics that reconciles with orders." },
      { label: "CMS & builders", title: "WordPress · Webflow · Wix · Squarespace", body: "Complete measurement on marketing and content sites." },
      { label: "Custom", title: "Headless · React · Next.js · Vue", body: "A small first-party pixel and full event API." },
    ],
    cta: "Every setup under 30 minutes.",
  },
  "security": {
    title: "Security Overview — SealMetrics",
    description: "Privacy-by-design, encryption, account isolation, retention controls and EU-only infrastructure.",
    eyebrow: "SECURITY OVERVIEW",
    hero: "Less personal data. *Less security risk.*",
    intro: "Security starts by refusing to collect the identifiers an analytics product does not need. Then we protect what remains with isolation, encryption and EU-only infrastructure.",
    stats: [{ value: "EU", label: "infrastructure" }, { value: "TLS", label: "in transit" }, { value: "AES", label: "at rest" }, { value: "TTL", label: "automatic retention" }],
    problemTitle: "Security review, without the theatre.",
    problems: [
      { title: "Privacy by design", body: "No visitor identity layer, personal profiles or cross-site tracking." },
      { title: "Isolation and access", body: "Per-account boundaries and least-privilege operational access." },
      { title: "Retention by default", body: "Automatic TTLs keep data only for the period the service requires." },
    ],
    solutionTitle: "What your security team receives.",
    solutions: [
      { title: "EU infrastructure", body: "Analytics processing and storage in Dublin." },
      { title: "Encryption", body: "Encrypted transport and storage across the service." },
      { title: "Incident process", body: "Documented management, notification and remediation." },
      { title: "Trust documentation", body: "DPA, security overview, subprocessors and policies in one place." },
    ],
    cta: "Does this pass your security review?",
  },
  "for/cmo": rolePage({
    title: "Analytics for CMOs — Defensible Attribution | SealMetrics", description: "Defend marketing budget with the neutral number finance signs against.", eyebrow: "FOR CMOs", hero: "Defend your budget with *the numbers your CFO signs against.*", intro: "You are the person explaining why paid spend grew while attributed revenue did not. SealMetrics gives brand, finance and agencies one neutral record.",
    pains: [["Three numbers, one meeting", "GA4, the agency and CRM disagree before the first slide."], ["Budget you cannot defend", "Incomplete attribution turns a strategic decision into an opinion contest."], ["The €200K direct bucket", "Revenue exists, but the channel evidence needed to repeat it is missing."], ["Agency versus internal data", "The relationship becomes defensive when each side reports a different reality."]],
    changes: [["Board-ready revenue", "Marketing performance reconciles with backend sales."], ["Defensible reallocation", "Move budget with evidence, not channel politics."], ["Neutral measurement", "Brand and agency work from the same source."], ["Live answers", "Ask LENS what changed before the next meeting."]],
    stats: [{ value: "100%", label: "traffic observed" }, { value: "1", label: "number for the room" }], cta: "See your real numbers in 30 minutes."
  }),
  "for/cto": rolePage({
    title: "Analytics for CTOs — Architecture & Setup | SealMetrics", description: "A tiny first-party pixel and an architecture engineering teams can approve.", eyebrow: "FOR CTOs", hero: "Analytics your engineering team *won't hate.*", intro: "One script. 846 bytes. First-party. No consent-mode configuration, server-side GTM project or three-month integration plan.",
    pains: [["146 KB for basic measurement", "The analytics stack taxes every page before it answers a business question."], ["Consent Mode is a maze", "Each implementation adds states, race conditions and compliance dependencies."], ["Server-side GTM expands scope", "Infrastructure grows while the underlying consent loss remains."], ["Thresholds change the answer", "The team cannot debug a metric that the vendor samples or models."]],
    changes: [["846-byte pixel", "A small first-party signal with no third-party identity graph."], ["No consent dependency", "Aggregate measurement does not wait for a banner state."], ["Full data access", "API, MCP and BigQuery without a premium export tier."], ["Side-by-side rollout", "Validate against the existing stack before replacing anything."]],
    stats: [{ value: "846 B", label: "pixel" }, { value: "5 min", label: "installation" }], cta: "See the integration in 15 minutes."
  }),
  "for/ecommerce": rolePage({
    title: "Analytics for eCommerce — Full Attribution | SealMetrics", description: "Cookieless eCommerce analytics that match store and CRM revenue.", eyebrow: "FOR ECOMMERCE", hero: "The analytics that *match your store.*", intro: "Your commerce backend knows the sale happened. SealMetrics reconnects that truth to the visit, channel, campaign and product that created it.",
    pains: [["Pixel versus store", "The eternal disagreement makes every acquisition report negotiable."], ["Cart adds without a source", "The buyer moved through the funnel, but consent loss removed the path."], ["Peak events get blurry", "Sampling and processing delays are most damaging on the day decisions matter most."], ["Products disappear in aggregates", "Channel totals hide which SKU actually earned the spend."]],
    changes: [["Store-aligned revenue", "Orders reconcile with complete observed traffic."], ["SKU-level truth", "See product, cart, checkout and purchase performance."], ["Live Promo Days", "Move budget during the campaign, not in tomorrow's post-mortem."], ["Real ROAS", "Every sale is counted before channel efficiency is calculated."]],
    stats: [{ value: "100%", label: "sales measured" }, { value: "LIVE", label: "peak reporting" }], cta: "Close the gap between your pixel and your store."
  }),
  "for/hotels": rolePage({
    title: "Analytics for Hotels — Direct-Booking | SealMetrics", description: "Match direct-booking attribution to PMS reality.", eyebrow: "FOR HOTELS & TRAVEL", hero: "The analytics that *match your PMS bookings.*", intro: "Direct revenue already closed. SealMetrics recovers the source, campaign and journey your consent-gated stack failed to carry into the booking.",
    pains: [["Bookings invisible to marketing", "CRM revenue exists without the acquisition evidence behind it."], ["OTA bleed", "Referrals and payment hops rewrite the channel that created demand."], ["Peak booking windows", "Last-minute decisions arrive after the reporting window."], ["Portfolio reconciliation", "Multi-property attribution becomes a spreadsheet project."]],
    changes: [["PMS-aligned revenue", "Direct bookings connect to complete inbound traffic."], ["Payment-domain control", "Internal and gateway referrals stop stealing attribution."], ["Multi-property truth", "Brands and properties share one measurement model."], ["Named proof", "Palladium and Dreamplace found material gaps in their previous stacks."]],
    stats: [{ value: "35%", label: "bookings recovered" }, { value: "+30%", label: "traffic vs GA" }], cta: "See the bookings you cannot currently attribute."
  }),
  "for/saas": rolePage({
    title: "Analytics for SaaS — PLG & Trial-to-Paid | SealMetrics", description: "Measure product-led growth and trial-to-paid funnels without consent loss.", eyebrow: "FOR SAAS", hero: "The analytics for *your freemium-to-paid funnel.*", intro: "The activation happened inside the product. The revenue closed later. SealMetrics keeps the path visible without creating a user surveillance layer.",
    pains: [["Trial signups become Direct", "The acquisition source disappears before activation."], ["Activation sampled at scale", "The event that predicts revenue becomes statistically convenient."], ["Ad blockers erase enterprise buyers", "Technical audiences are systematically undercounted."], ["PLG versus sales-led", "Revenue ownership is debated because the journey is incomplete."]],
    changes: [["Complete acquisition", "Every anonymous visit can contribute to aggregate channel truth."], ["Activation measurement", "Track product milestones without a personal analytics profile."], ["Trial-to-paid evidence", "Connect conversions to the source that created the pipeline."], ["EU-ready architecture", "Analytics no longer adds personal-data exposure to the product."]],
    stats: [{ value: "100%", label: "aggregate funnel" }, { value: "0 PII", label: "analytics profile" }], cta: "See your real activation rate."
  }),
  "for/agencies": rolePage({
    title: "Analytics for Marketing Agencies | SealMetrics", description: "A neutral measurement layer clients and agencies stop arguing with.", eyebrow: "FOR AGENCIES", hero: "The analytics your clients *stop arguing with.*", intro: "Stop defending attribution reports. Become the advisor who shows the client what happened and what to do next.",
    pains: [["Every QBR becomes a trial", "The client disputes the source before discussing the decision."], ["Pixel/CRM gaps eat trust", "Performance looks inflated or incomplete depending on the room."], ["Portfolio clients fragment", "Every brand arrives with a different model and taxonomy."], ["Onboarding takes weeks", "Tag plans and consent states delay strategic work."]],
    changes: [["Neutral layer", "Client, brand and performance teams share complete data."], ["Defensible performance", "Campaign revenue reconciles with backend sales."], ["Fast onboarding", "One pixel starts the comparison without a migration."], ["Advisory leverage", "Spend less time defending data and more time reallocating budget."]],
    stats: [{ value: "1", label: "source of truth" }, { value: "5 min", label: "first-party install" }], cta: "Stop being the middle. Be the advisor."
  }),
  "for/media": rolePage({
    title: "Analytics for Media & Publishers | SealMetrics", description: "First-party audience analytics that survive consent loss and ad blockers.", eyebrow: "FOR MEDIA & PUBLISHERS", hero: "Analytics that *survive ad blockers.*", intro: "A privacy-aware reader should not disappear from aggregate audience measurement. SealMetrics restores the evidence behind content, subscription and newsletter decisions.",
    pains: [["Half the audience vanishes", "Ad blockers and consent rejection remove the readers most likely to care about privacy."], ["Ad yield on a sample", "Inventory decisions rely on an incomplete view of attention."], ["Newsletter attribution breaks", "The source disappears before subscription or registration."], ["Paywall paths go dark", "Conversion analysis stops at the consent boundary."]],
    changes: [["Complete readership", "Observe aggregate page and content performance first party."], ["Real engagement", "Measure articles, sections and content groups without a personal profile."], ["Subscription evidence", "Connect acquisition sources to paid outcomes."], ["EU-hosted data", "Audience measurement stays under European jurisdiction."]],
    stats: [{ value: "100%", label: "aggregate audience" }, { value: "1st", label: "first-party signal" }], cta: "See the audience your current analytics cannot."
  }),
  "for/finance": rolePage({
    title: "Analytics for Finance — Compliance | SealMetrics", description: "EU-hosted analytics with zero visitor profiles and a shorter vendor review.", eyebrow: "FOR FINANCE", hero: "Analytics with *bank-grade restraint.*", intro: "The strongest control is not collecting data you do not need. SealMetrics measures performance without creating personal visitor profiles or exporting them outside the EU.",
    pains: [["Four-month vendor review", "The identity layer turns analytics into a major privacy assessment."], ["Campaigns wait for legal", "Measurement changes inherit the same personal-data risk."], ["Residency uncertainty", "Visitor data crosses jurisdictions through opaque subprocessors."], ["Audit trails need engineering", "Compliance evidence is scattered across tools and teams."]],
    changes: [["Zero visitor profiles", "Aggregate measurement removes the most sensitive architectural dependency."], ["EU-only processing", "Analytics infrastructure remains in Dublin."], ["Public trust documents", "DPA, security, privacy and terms live in one center."], ["Revenue reconciliation", "Marketing performance can be signed against backend truth."]],
    stats: [{ value: "EU", label: "processing" }, { value: "0", label: "visitor profiles" }], cta: "Skip the four-month review."
  }),
  "for/healthcare": rolePage({
    title: "Analytics for Healthcare — Privacy-First | SealMetrics", description: "Measure appointment and consultation funnels without patient profiles.", eyebrow: "FOR HEALTHCARE", hero: "Analytics with *zero patient-data exposure.*", intro: "Understand treatment-page performance and appointment funnels in aggregate—without turning a healthcare visitor into an advertising profile.",
    pains: [["GA4 becomes a legal risk", "Health context makes ordinary behavioral tracking unusually sensitive."], ["Analytics disabled on key pages", "The safest quick fix removes the evidence needed to improve access."], ["Appointment funnels go dark", "Teams cannot see where prospective patients abandon."], ["Compliance blocks iteration", "Every measurement request creates a new privacy debate."]],
    changes: [["Aggregate measurement", "Count page and funnel events without identifying the person."], ["No cookies or fingerprinting", "The architecture avoids persistent visitor identity."], ["EU infrastructure", "Processing stays in Dublin."], ["Useful optimization", "Improve appointment and consultation paths with defensible evidence."]],
    stats: [{ value: "0", label: "patient profiles" }, { value: "100%", label: "aggregate events" }], cta: "Get analytics legal does not block."
  }),
  "for/education": rolePage({
    title: "Analytics for Education — GDPR Funnels | SealMetrics", description: "Measure student-facing sites without persistent identifiers.", eyebrow: "FOR EDUCATION", hero: "Analytics for student-facing sites, *without the compliance cost.*", intro: "Universities, EdTech and MOOCs serve mixed-age audiences across jurisdictions. Aggregate measurement keeps learning-flow evidence without building student profiles.",
    pains: [["Minor-data rules expand risk", "Ordinary analytics architecture becomes inappropriate for young audiences."], ["Parental consent is impractical", "The measurement layer creates a workflow unrelated to learning."], ["Residency rules vary", "Cross-border visitor processing complicates every rollout."], ["Learning flows cannot improve", "Teams remove analytics from the pages that need the most iteration."]],
    changes: [["Age-neutral architecture", "No persistent identity means fewer child-data dependencies."], ["EU-hosted processing", "Audience measurement remains in Dublin."], ["Complete funnels", "Observe registration and learning steps in aggregate."], ["Faster experimentation", "Improve content paths without adding a surveillance layer."]],
    stats: [{ value: "0", label: "student profiles" }, { value: "EU", label: "data residency" }], cta: "Get analytics that work for every age group."
  }),
  "vs-ga4": comparisonPage({
    title: "SealMetrics vs Google Analytics 4 — Complete data, no spin", description: "GA4 loses EU traffic to consent and blockers. SealMetrics observes complete aggregate data.", hero: "GA4 shows a consent-shaped fraction. *SealMetrics shows what happened.*", intro: "This is not a feature war. Run both for 30 days, compare them against backend revenue and keep the version that reconciles.", opponent: "Google Analytics 4",
    problems: [["Organic goes missing", "Consent rejection removes visits before GA4 classifies them."], ["Meta conversions disagree", "Platform, GA4 and CRM optimize different populations."], ["Direct becomes a landfill", "Lost attribution accumulates in the least useful channel."], ["Peak reporting slows", "Modeling and processing are weakest when Promo Day decisions are live."]],
    stats: [{ value: "40–60%", label: "typical EU blind spot" }, { value: "100%", label: "SealMetrics observed data" }], cta: "Run both. Let your backend decide."
  }),
  "vs/ga360": comparisonPage({
    title: "SealMetrics vs GA360 — Enterprise data for less", description: "Complete data without the GA360 invoice or consent blind spot.", hero: "Enterprise data *without the $150K invoice.*", intro: "GA360 expands limits and service. It does not change the consent-dependent capture architecture underneath the data.", opponent: "GA360",
    problems: [["Premium incomplete data", "A larger processing allowance cannot observe users who never consented."], ["Annual enterprise cost", "The contract buys scale before it buys completeness."], ["Complex implementation", "Teams add server-side infrastructure to defend an architecture they do not control."], ["Specialist dependence", "Business questions wait for analytics resources."]],
    stats: [{ value: "$150K+", label: "typical annual GA360 cost" }, { value: "€499", label: "SealMetrics Growth / month annual" }], cta: "Get enterprise data. Skip the enterprise invoice."
  }),
  "vs/adobe-analytics": comparisonPage({
    title: "SealMetrics vs Adobe Analytics — Enterprise alternative", description: "Complete, privacy-first analytics without a specialist implementation.", hero: "Enterprise power. *Zero enterprise overhead.*", intro: "Adobe can model almost any reporting structure—after the implementation, consultancy and consent layer. SealMetrics starts with complete observable reality.", opponent: "Adobe Analytics",
    problems: [["Six-month implementation", "Taxonomy and tagging delay the first trustworthy answer."], ["Specialists required", "Business teams cannot safely explore without analyst support."], ["Consent loss remains", "Enterprise configuration does not restore traffic never collected."], ["Cost compounds", "Licensing, consultancy and maintenance become one analytics budget."]],
    stats: [{ value: "$100K+", label: "typical annual cost" }, { value: "5 min", label: "SealMetrics first data" }], cta: "Skip the six-month implementation."
  }),
  "vs/piwik-pro": comparisonPage({
    title: "SealMetrics vs Piwik PRO — EU hosting plus complete capture", description: "EU hosting is useful. Consentless architecture solves the measurement gap.", hero: "EU hosting is the beginning, *not the finish line.*", intro: "Piwik PRO addresses residency. SealMetrics also removes the cookie and identity architecture that creates the consent blind spot.", opponent: "Piwik PRO",
    problems: [["EU-hosted but cookie-based", "Residency changes where incomplete data lives, not how it is captured."], ["Consent still gates truth", "Declined visitors remain absent from channel and revenue reporting."], ["Configuration overhead", "Privacy controls increase operational complexity."], ["Reporting before reconciliation", "The dashboard can remain detached from backend reality."]],
    stats: [{ value: "EU", label: "both platforms" }, { value: "100%", label: "SealMetrics aggregate capture" }], cta: "Choose EU hosting plus complete capture."
  }),
  "pricing": {
    title: "SealMetrics Pricing — Pay for humans, not bots", description: "Free Agentic tier and paid plans from €499/month annually.", eyebrow: "PRICING", hero: "Pay for *humans.* Not bots. Not guesswork.", intro: "Every paid plan includes the same complete architecture. You pay more when human usage grows—not when you need a feature that makes the data useful.", kind: "pricing",
    stats: [{ value: "FREE", label: "up to 1M human events" }, { value: "€499", label: "Growth / month annual" }, { value: "€899", label: "Scale / month annual" }],
    cta: "Start measuring reality."
  },
  "demo": {
    title: "Book a Demo — SealMetrics", description: "A 30-minute walkthrough of the traffic and sales your analytics miss.", eyebrow: "BOOK A DEMO", hero: "See what your analytics *have been missing.*", intro: "Tell us about your stack. We will prepare the right questions before the call and show you where the gap appears on your own site.", kind: "demo",
    stats: [{ value: "30 min", label: "personalized walkthrough" }, { value: "0", label: "generic sales deck" }, { value: "1", label: "real data question" }], cta: "Pick a time. See the gap."
  },
  "demo-access": {
    title: "Demo Account — SealMetrics", description: "Explore a SealMetrics demo account on your own.", eyebrow: "EXPLORE THE PRODUCT", hero: "No call. No script. *Just look around.*", intro: "Open the demo environment and explore revenue, channels, campaigns and LENS at your own pace.", kind: "demo",
    problems: [{ title: "Revenue", body: "See the verified number and how it moves by channel." }, { title: "Attribution", body: "Compare sources without a consent-shaped blind spot." }, { title: "LENS", body: "Ask plain-language questions against demo data." }], cta: "Explore the demo account."
  },
  "data-loss-calculator": {
    title: "Data Loss Calculator — SealMetrics", description: "Estimate how much traffic and revenue your current analytics cannot see.", eyebrow: "DATA LOSS CALCULATOR", hero: "How much revenue is *invisible* to your analytics?", intro: "Consent rejection, blockers and browser restrictions remove evidence before your dashboard can count it. Put in your numbers and see the likely gap.", kind: "calculator", cta: "See the gap on your actual traffic."
  },
  "real-roas": {
    title: "Your real ROAS — SealMetrics", description: "Calculate return on ad spend with every observed sale included.", eyebrow: "REAL ROAS", hero: "Your ROAS isn't low. *It may be incomplete.*", intro: "Same campaign. Same spend. More of the resulting sales observed. Real ROAS is what happens when the denominator stays fixed and the missing revenue returns.",
    stats: [{ value: "2.4×", label: "consent-gated view" }, { value: "4.1×", label: "complete observed view" }],
    problemTitle: "A ratio is only as honest as its numerator.", problems: [{ title: "Spend is complete", body: "Ad platforms charge for every click whether analytics sees the buyer or not." }, { title: "Revenue is partial", body: "Consent loss removes sales from the attributed return." }, { title: "The ratio punishes winners", body: "Privacy-aware audiences can make a productive channel look inefficient." }],
    solutionTitle: "What changes with complete measurement.", solutions: [{ title: "Every sale counted", body: "Attributed revenue starts from complete observed conversion data." }, { title: "Channels compared fairly", body: "Consent mix no longer determines the apparent winner." }, { title: "Budget moves sooner", body: "Real-time ROAS supports decisions during the campaign." }], cta: "Measure your real ROAS."
  },
  "blog": {
    title: "Blog — SealMetrics", description: "Thinking on analytics, attribution and privacy-first measurement.", eyebrow: "BLOG", hero: "Thinking about analytics, *done properly.*", intro: "Practical arguments for teams that prefer evidence to dashboards, written from two decades of analytics work.", kind: "listing",
    items: [
      { label: "Analytics", title: "Self-Service Analytics for Marketing Teams", body: "How LENS gives business teams direct answers without turning data governance into chaos." },
      { label: "Buyer's guide", title: "The Best Web Analytics Tool: 12 Requirements", body: "The architectural questions that matter more than a feature checklist." },
      { label: "Privacy", title: "Is Adobe Analytics GDPR Compliant?", body: "A practical assessment of data flows, consent and enterprise configuration." },
      { label: "Guide", title: "Cookieless Analytics for eCommerce: The 2026 Guide", body: "What complete measurement looks like when cookies are no longer the foundation." },
      { label: "Hotels", title: "Cookieless Analytics for Hotels", body: "Direct-booking attribution that reconciles with PMS truth." },
      { label: "SaaS", title: "PLG Without Consent Banners", body: "Measure activation and trial-to-paid performance without personal profiles." },
    ], cta: "Read the argument. Then test it."
  },
  "case-studies": {
    title: "Case Studies — SealMetrics", description: "Named clients, real numbers and honest write-ups.", eyebrow: "CASE STUDIES", hero: "Real teams. Real numbers. *Honest write-ups.*", intro: "No anonymous logos and no miraculous percentage without context. These teams compared SealMetrics against the systems already running their business.", kind: "listing",
    stats: [{ value: "40%", label: "traffic recovered · Palladium" }, { value: "35%", label: "bookings recovered · Palladium" }, { value: "+30%", label: "traffic · Dreamplace" }],
    items: [
      { label: "Palladium Hotel Group", title: "From unattributed traffic to a neutral source of truth", body: "Recovered 40% of unattributed traffic, 35% of bookings and improved Display CPS by 165%." },
      { label: "Dreamplace Hotels", title: "Closing the gap between analytics and CRM", body: "Observed 30% more traffic than Google Analytics and closed a 15–20% sales-attribution gap." },
    ], cta: "See your own case study in 30 minutes."
  },
  "videos": {
    title: "Videos — SealMetrics", description: "Product demos and tutorials for complete cookieless analytics.", eyebrow: "VIDEOS", hero: "See it. Understand it. *Start tracking.*", intro: "Short product walkthroughs for the questions teams actually ask during setup and analysis.", kind: "listing",
    items: [{ label: "Product demo", title: "SealMetrics in 10 minutes", body: "Traffic, attribution, revenue and LENS from first visit to decision." }, { label: "Setup", title: "Install the first-party pixel", body: "A direct walkthrough for native platforms and custom sites." }, { label: "Attribution", title: "Compare GA4 side by side", body: "Use backend revenue to quantify the gap in your current stack." }, { label: "LENS", title: "Ask your data a real question", body: "From plain-language prompt to traceable answer." }], cta: "Start tracking without cookies today."
  },
  "glossary": {
    title: "Analytics Glossary — Web, GDPR & Attribution Terms", description: "Analytics terms in plain language for European marketing and data teams.", eyebrow: "GLOSSARY", hero: "Analytics terms, *in plain language.*", intro: "No circular definitions and no vendor fog. What the term means, why it matters and where it becomes misleading.", kind: "listing",
    items: [{ label: "A", title: "Anonymization", body: "A transformation that prevents data from being linked back to an identifiable person." }, { label: "A", title: "Average Order Value", body: "Revenue divided by completed orders for the selected period." }, { label: "B", title: "Bot Traffic", body: "Automated activity that should not be priced or interpreted as human demand." }, { label: "B", title: "Browser Fingerprinting", body: "Combining device signals to identify a browser without a cookie." }, { label: "C", title: "Channel Grouping", body: "Rules that turn source and medium evidence into business-readable acquisition categories." }, { label: "C", title: "Conversion Rate", body: "Conversions divided by the relevant observed opportunities—not an arbitrary consent subset." }], cta: "Understand the number before optimizing it."
  },
  "changelog": {
    title: "Changelog — SealMetrics", description: "What SealMetrics has shipped recently.", eyebrow: "CHANGELOG", hero: "What we have shipped. *No roadmap theatre.*", intro: "Product changes, fixes and capabilities—with enough detail to understand what actually improved.", kind: "listing",
    items: [{ label: "July 2026", title: "Seal AI Private", body: "EU-hosted private AI with token packs and no shared-model training." }, { label: "July 2026", title: "Sources report", body: "Referral traffic grouped by domain with entrances, revenue and conversion evidence." }, { label: "July 2026", title: "Custom Channel Grouping", body: "Create and test rules from the dashboard, CSV or MCP." }, { label: "June 2026", title: "Bot-blocking update", body: "Reduced false positives while keeping human-event billing honest." }, { label: "May 2026", title: "Attribution fixes", body: "Internal UTM hits no longer open an incorrect new session." }, { label: "February 2026", title: "API reliability", body: "Resolved authorization issues across exports and batch endpoints." }], cta: "See what complete analytics keeps becoming."
  },
  "about": {
    title: "About SealMetrics — Founder-led analytics for Europe", description: "EU-founded, EU-hosted and built after 20 years of analytics work.", eyebrow: "ABOUT SEALMETRICS", hero: "Built so European teams could *trust their own data again.*", intro: "SealMetrics began after two decades watching smart teams make expensive decisions with numbers no one in the room fully believed.",
    stats: [{ value: "20+", label: "years in analytics" }, { value: "EU", label: "founded and hosted" }, { value: "2020", label: "company founded" }],
    problemTitle: "The problem was never another missing dashboard.", problems: [{ title: "Data nobody trusted", body: "Brand, agency and finance arrived with competing versions of revenue." }, { title: "Privacy bolted on", body: "Consent layers tried to repair an architecture designed around identity." }, { title: "Enterprise without clarity", body: "More tools increased sophistication faster than confidence." }],
    solutionTitle: "What we chose to build instead.", solutions: [{ title: "Reality first", body: "Observe complete aggregate events before calculating performance." }, { title: "Privacy as architecture", body: "Remove cookies, identifiers and personal profiles from the foundation." }, { title: "Founder-led", body: "Keep the product close to the people accountable for customer outcomes." }, { title: "European by design", body: "Build and host the service under the rules its customers operate within." }], cta: "Talk directly to the founder."
  },
  "careers": {
    title: "Work With Us — SealMetrics", description: "Apply with public work, not a personal-data funnel.", eyebrow: "WORK WITH US", hero: "Show us your work, *not your CV.*", intro: "The standard hiring funnel collects personal data it never needed. Send a public link that shows what you think, build, write, sell or support.", kind: "listing",
    items: [{ label: "Team", title: "Engineering", body: "Systems, data infrastructure, APIs and product performance." }, { label: "Team", title: "Product & Design", body: "Interfaces and narratives that make complicated evidence usable." }, { label: "Team", title: "Growth & Marketing", body: "Arguments, experiments and content that earn attention honestly." }, { label: "Team", title: "Sales & Partnerships", body: "Commercial work grounded in the prospect's actual measurement problem." }, { label: "Team", title: "Customer Success", body: "Turn implementation into decisions customers can defend." }, { label: "Team", title: "Open application", body: "If your strongest work does not fit a box, show us anyway." }], cta: "Pick a door. Show us what you shipped."
  },
  "privacy": {
    title: "Privacy Policy — Sealmetrics", description: "How SealMetrics handles, protects and limits data.", eyebrow: "LEGAL · PRIVACY", hero: "Privacy Policy", intro: "A plain-language map of what SealMetrics collects on its own site, what it processes for clients and the rights available to individuals.", kind: "legal",
    items: [{ title: "1. Who we are", body: "Sealmetrics SL, based in Barcelona, is responsible for the service and the information described in this policy." }, { title: "2. Data on sealmetrics.com", body: "We process information submitted through account, demo and contact interactions, plus strictly necessary service and security data." }, { title: "3. Data on client websites", body: "The analytics architecture counts aggregate events without cookies, fingerprints or persistent visitor profiles." }, { title: "4. Legal basis", body: "Processing depends on the relevant service relationship, legitimate operational needs and legal obligations." }, { title: "5. Storage and residency", body: "Analytics infrastructure is hosted in Dublin, Ireland." }, { title: "6. Retention", body: "Data is retained only for defined service, contractual and legal periods." }, { title: "7. Your rights", body: "Where applicable, individuals may exercise access, correction, deletion, objection, restriction and portability rights." }, { title: "8. Third-party sharing", body: "Service providers are limited, documented and governed by appropriate agreements." }, { title: "9. Contact", body: "Privacy questions and rights requests can be directed through the official SealMetrics contact channels." }],
    note: "For production, preserve the complete current legal wording and obtain legal review before publication."
  },
  "terms": {
    title: "Terms of Service — Sealmetrics", description: "Plans, billing, acceptable use, ownership, liability and termination.", eyebrow: "LEGAL · TERMS", hero: "Terms of Service", intro: "The contractual rules governing accounts, plans, use of the service, billing and responsibilities.", kind: "legal",
    items: [{ title: "1. Introduction and acceptance", body: "Using the service requires acceptance of the current terms and any applicable order." }, { title: "2. Definitions", body: "The terms define the customer, account, site, event, subscription and related service concepts." }, { title: "3. The service", body: "SealMetrics provides analytics capture, reporting, attribution, integrations and related capabilities according to the selected plan." }, { title: "4. Accounts", body: "Customers are responsible for accurate registration, authorized users and account security." }, { title: "5. Plans and pricing", body: "Usage limits, features and commercial terms follow the selected plan and order." }, { title: "6. Billing and payments", body: "Subscriptions, renewals, taxes, disputes and non-payment follow the stated billing cycle and commercial agreement." }, { title: "7. Acceptable use", body: "The service may not be abused, disrupted, reverse engineered unlawfully or used to violate rights or applicable law." }, { title: "8. Data ownership", body: "Customers retain ownership of their data; SealMetrics receives only the rights required to provide the service." }, { title: "9. Liability and termination", body: "Limits, exclusions and termination rights apply as stated in the complete current agreement." }],
    note: "This redesigned preview is not a replacement for the complete signed Terms. Preserve the current legal text for production."
  },
  "dpa": {
    title: "Data Processing Agreement — Sealmetrics", description: "Article 28 GDPR agreement, safeguards, subprocessors and security measures.", eyebrow: "LEGAL · DPA", hero: "Data Processing Agreement", intro: "The Article 28 framework governing processing instructions, security, subprocessors, rights requests and audit evidence.", kind: "legal",
    items: [{ title: "1. Definitions", body: "Terms follow GDPR and the service agreement, including controller, processor, personal data and processing." }, { title: "2. Subject matter and instructions", body: "SealMetrics processes data only to provide the contracted service and on documented customer instructions." }, { title: "3. Audience-measurement guarantees", body: "The architecture is designed around strict measurement purpose, data minimization and the absence of persistent visitor identification." }, { title: "4. Confidentiality and security", body: "Authorized personnel are bound by confidentiality and appropriate Article 32 technical and organizational measures." }, { title: "5. Subprocessors", body: "Subprocessors are documented, contractually controlled and subject to the applicable notification process." }, { title: "6. Data-subject rights", body: "SealMetrics assists customers with applicable requests in line with the nature of processing." }, { title: "7. Breaches", body: "Documented detection, investigation and notification procedures support Articles 33 and 34 obligations." }, { title: "8. DPIAs and audits", body: "SealMetrics provides reasonable information and assistance for impact assessments, consultation and audit obligations." }, { title: "9. Deletion and return", body: "Data is deleted or returned according to termination instructions, retention settings and legal requirements." }],
    note: "For production and signature, use the complete current DPA version and legal review."
  },
  "trust": {
    title: "Trust Center — Sealmetrics", description: "Security, legal and compliance documentation in one place.", eyebrow: "TRUST CENTER", hero: "Evidence for the people who *have to sign off.*", intro: "The trust center collects the documents security, privacy, procurement and legal teams need to evaluate SealMetrics.", kind: "legal",
    items: [{ title: "Public documents", body: "Security overview, Privacy Policy, Terms of Service and Data Processing Agreement." }, { title: "Available on request", body: "Subprocessor details, additional security materials and relevant assessment evidence." }, { title: "Architecture", body: "No visitor profiles, no cookies, EU-hosted analytics processing and documented retention." }, { title: "Subscribe to changes", body: "Material updates to trust documentation can be followed through the official notification process." }], cta: "Start the review with the architecture."
  },
};
